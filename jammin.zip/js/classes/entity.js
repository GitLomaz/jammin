class Entity extends Phaser.GameObjects.Container {
  constructor(x, y) {
    super(scene, x, y);
  }
}